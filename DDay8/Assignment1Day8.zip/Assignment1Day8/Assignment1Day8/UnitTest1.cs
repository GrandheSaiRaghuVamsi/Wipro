namespace Assignment1Day8
{
    public class Tests
    {
        public int i,j;
        public bool result;

        [SetUp]
        public void CheckNonNegative()
        {
            if(i>0 &&  j>0)
            {
                result = true;
            }
            else
            {
                result = false;
            }
        }

        [Test]
        public void TestAdd()
        {
            if(result)
            {
                MathOp m = new MathOp();
                int res = m.Add(10, 20);
                Assert.AreEqual(30, res);
            }
        }

        [Test]
        public void TestSub()
        {
            if (result)
            {
                MathOp ms = new MathOp();
                int res = ms.Sub(10, 20);
                Assert.AreEqual(10, res);
            }
        }

        [Test]
        public void TestMul()
        {
            if (result)
            {
                MathOp mm = new MathOp();
                int res = mm.Mul(10, 20);
                Assert.AreEqual(20, res);
            }
        }

        [Test]
        public void TestDiv()
        {
            if (result)
            {
                MathOp md = new MathOp();
                int res = md.Div(10, 20);
                Assert.AreEqual(200, res);
            }
        }

        [Test]
        public void Divide_WhenDividingByZero_ThrowsDivideByZeroException()
        {
            // Arrange
            int a = 5;
            int b = 0;

            MathOp M = new MathOp();
            // Act & Assert
            var ex = Assert.Throws<DivideByZeroException>(() => M.Div(a, b));
            Assert.AreEqual("Attempted to divide by zero.", ex.Message);
            Console.WriteLine(ex.Message);
        }


        // Test for edge case (adding zero)
        [Test]
        public void Add_WhenAddingZero_ReturnsSameNumber()
        {
            // Arrange
            int a = 5;
            int b = 0;

            // Act
            MathOp mda = new MathOp();
            int e = mda.Add(a, b);
            Assert.AreEqual(5, e);

        }

        // Test for edge case (subtracting zero)
        [Test]
        public void Subtract_WhenSubtractingZero_ReturnsSameNumber()
        {
            // Arrange
            int a = 5;
            int b = 0;

            // Act
            MathOp mda = new MathOp();
            int e = mda.Sub(a, b);
            Assert.AreEqual(5, e);
        }


    }
}