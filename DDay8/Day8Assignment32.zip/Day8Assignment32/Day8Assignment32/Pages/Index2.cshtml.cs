using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;


namespace Day8Assignment32.Pages
{
    public class Index2Model : PageModel
    {
        public List<string> Items { get; set; } = new();
        [BindProperty] public string NewItem { get; set; }

        public void OnGet()
        {
            Items.Add("Item 1");
            Items.Add("Item 2");
        }

        public IActionResult OnPost()
        {
            if (!string.IsNullOrEmpty(NewItem))
            {
                Items.Add(NewItem);
            }
            return Page();
        }

    }
}
