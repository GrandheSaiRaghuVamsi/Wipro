using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Day8Assignment32.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
