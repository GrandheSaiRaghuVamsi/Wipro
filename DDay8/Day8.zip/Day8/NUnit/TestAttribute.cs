﻿
namespace NUnit
{
    internal class TestAttribute : Attribute
    {
    }
}