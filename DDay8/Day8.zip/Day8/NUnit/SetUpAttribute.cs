﻿
namespace NUnit
{
    internal class SetUpAttribute : Attribute
    {
    }
}