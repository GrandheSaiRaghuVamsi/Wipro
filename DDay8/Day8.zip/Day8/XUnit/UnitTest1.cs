using Day8;
namespace XUnit
{
    public class UnitTest1
    {
        //[Fact]
        public void Test1()
        {

        }
    }
}