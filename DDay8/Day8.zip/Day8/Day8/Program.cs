﻿using Day8;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");

    }
}