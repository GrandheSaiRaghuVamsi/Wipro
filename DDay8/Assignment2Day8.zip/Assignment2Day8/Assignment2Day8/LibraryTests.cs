namespace Assignment2Day8
{
    public class LibraryTests
    {
        private Library library;
        private Book book;
        private Borrower borrower;

        [SetUp]
        public void Setup()
        {
            library = new Library();
            book = new Book("The Book of Divine", "Vamsi Paidipally", "9948280");
            borrower = new Borrower("SAI", "201fa04009");
            library.AddBook(book);
            library.RegisterBorrower(borrower);
        }

        [Test]
        public void AddBook_ShouldIncreaseBookCount()
        {
            Assert.AreEqual(1, library.Books.Count);
        }

        [Test]
        public void RegisterBorrower_ShouldIncreaseBorrowerCount()
        {
            Assert.AreEqual(1, library.Borrowers.Count);
        }

        [Test]
        public void BorrowBook_ShouldMarkBookAsBorrowed()
        {
            bool result = library.BorrowBook("9948280", "201fa04009");
            Assert.IsTrue(result);
            Assert.IsTrue(book.IsBorrowed);
            Assert.AreEqual(1, borrower.BorrowedBooks.Count);
        }

        [Test]
        public void ReturnBook_ShouldMarkBookAsAvailable()
        {
            library.BorrowBook("9948280", "201fa04009");
            bool result = library.ReturnBook("9948280", "201fa04009");
            Assert.IsTrue(result);
            Assert.IsFalse(book.IsBorrowed);
            Assert.AreEqual(0, borrower.BorrowedBooks.Count);
        }
    }
}