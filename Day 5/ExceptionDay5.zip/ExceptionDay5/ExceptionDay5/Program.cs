﻿internal class Program
{
    private static void Main(string[] args)
    {
        try
        {
            Console.WriteLine("Enter the age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            if (age < 18)
            {
                throw new AgeException("Invalid Age. So You are not eligible");
            }
            Console.WriteLine("Enter the value of a: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the vlue of b: ");
            int b = Convert.ToInt32(Console.ReadLine());

            int c = a / b;
            Console.WriteLine(c);
            int[] ar = new int[5];
            for (int i = 0; i < 7; i++)
            {
                Console.WriteLine(ar[i]);
            }
        }
        catch (FormatException ex)
        {
            Console.WriteLine("This is the FormatException block");
            Console.WriteLine(ex.Message);
        }
        catch (DivideByZeroException ex)
        {
            Console.WriteLine("This is the DivideByZeroException block");
            Console.WriteLine(ex.Message);
        }
        catch (AgeException ex)
        {
            Console.WriteLine("This is the AgeException block");
            Console.WriteLine(ex.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine("This is the catch (Exception ex) block");
            Console.WriteLine(ex.ToString());
        }
        finally
        {
            Console.WriteLine("This is the finally block");
        }
    }
}