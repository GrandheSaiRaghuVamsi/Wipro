﻿
[Serializable]
internal class AgeException : Exception
{
    public AgeException()
    {
    }

    public AgeException(string? message) : base(message)
    {
    }

    public AgeException(string? message, Exception? innerException) : base(message, innerException)
    {
    }
}