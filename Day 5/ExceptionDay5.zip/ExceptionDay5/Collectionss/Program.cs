﻿// See https://aka.ms/new-console-template for more information
using System.Collections;

Console.WriteLine("Hello, World!");

ArrayList arrl = new ArrayList();
arrl.Add(111);
arrl.Add("sai");
arrl.Add(true);

foreach (object i in arrl)
{
    Console.WriteLine(i);
}
Console.WriteLine("COUNT " + arrl.Count);
Console.WriteLine("CAPACITY "+arrl.Capacity);

Console.WriteLine();
string[] cities = { "sai", "raghu", "vamsi" };
arrl.AddRange(cities);
foreach (object i in arrl)
{
    Console.WriteLine(i);
}
Console.WriteLine("COUNT " + arrl.Count);
Console.WriteLine("CAPACITY " + arrl.Capacity);

Console.WriteLine();
arrl.Insert(1, "one");
foreach (object i in arrl)
{
    Console.WriteLine(i);
}
Console.WriteLine("COUNT " + arrl.Count);
Console.WriteLine("CAPACITY " + arrl.Capacity);

Console.WriteLine();
arrl.InsertRange(0,cities);
foreach (object i in arrl)
{
    Console.WriteLine(i);
}
Console.WriteLine("COUNT " + arrl.Count);
Console.WriteLine("CAPACITY " + arrl.Capacity);
Console.WriteLine();

arrl.Remove("sai");
foreach (object i in arrl)
{
    Console.WriteLine(i);
}
Console.WriteLine("COUNT " + arrl.Count);
Console.WriteLine("CAPACITY " + arrl.Capacity);
Console.WriteLine();

arrl.RemoveAt(0);
foreach (object i in arrl)
{
    Console.WriteLine(i);
}
Console.WriteLine("COUNT " + arrl.Count);
Console.WriteLine("CAPACITY " + arrl.Capacity);
Console.WriteLine();

arrl.RemoveRange(0,2);
foreach (object i in arrl)
{
    Console.WriteLine(i);
}
Console.WriteLine("COUNT " + arrl.Count);
Console.WriteLine("CAPACITY " + arrl.Capacity);
Console.WriteLine();

arrl[1] = "GRANDHE";
foreach (object i in arrl)
{
    Console.WriteLine(i);
}
Console.WriteLine("COUNT " + arrl.Count);
Console.WriteLine("CAPACITY " + arrl.Capacity);
Console.WriteLine();

Console.WriteLine(arrl.Contains("GRANDHE"));





