﻿internal class Account
{
    public Account()
    {
    }

    public int Accid { get; set; }
    public string AccName { get; set; }
    public int AccBalance { get; set; }
}