﻿// See https://aka.ms/new-console-template for more information
using GENERICCOLLECTIONS;

Console.WriteLine("Hello, World!");

List<string> s  = new List<string>();
//IList<string> list = new List<string>();
s.Add("jaya");
s.Add("siva");
s.Add("naga");

foreach (string item in s)
{
    Console.WriteLine(item);
}

List<Customer> customers = new List<Customer>();
customers.Add(new Customer() {cid = 11, name = "sai"});
customers.Add(new Customer() { cid = 121, name = "Raghu" });
customers.Add(new Customer() { cid = 131, name = "vamsi" });

foreach(Customer customer in customers)
{
    Console.WriteLine(customer.cid + "  "+customer.name);
}

Stack<int> sd = new Stack<int>();
sd.Push(1);
sd.Push(2);
sd.Push(3);
sd.Push(10);
sd.Push(20);
sd.Push(30);

foreach (int d in sd)
{
    Console.WriteLine(d);
}
Console.WriteLine();
Console.WriteLine(sd.Peek());
Console.WriteLine();
foreach (int d in sd)
{
    Console.WriteLine(d);
}
Console.WriteLine();
Console.WriteLine(sd.Pop());
Console.WriteLine();
foreach (int d in sd)
{
    Console.WriteLine(d);
}
Console.WriteLine();

Queue<int> qw = new Queue<int>();
qw.Enqueue(1);
qw.Enqueue(2);
qw.Enqueue(3);
qw.Enqueue(4);
qw.Enqueue(5);
qw.Enqueue(6);
qw.Enqueue(7);
qw.Enqueue(8);
foreach (int d in qw)
{
    Console.WriteLine(d);
}
Console.WriteLine();

SortedList<int,int> sf = new SortedList<int,int>();
sf.Add(1,2);
sf.Add(2,3);
sf.Add(3,4);
sf.Add(0,5);
foreach (KeyValuePair<int,int> d in sf)
{
    Console.WriteLine(d);
}

